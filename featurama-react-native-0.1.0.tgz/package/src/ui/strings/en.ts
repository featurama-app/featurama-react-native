export interface FeaturamaStrings {
  title: string;
  filterNew: string;
  filterPlanned: string;
  filterInProgress: string;
  filterDone: string;
  titlePlaceholder: string;
  descriptionPlaceholder: string;
  submit: string;
  cancel: string;
  empty: string;
  emptyHint: string;
  error: string;
  retry: string;
}

export const defaultStrings: FeaturamaStrings = {
  title: 'Feature Requests',
  filterNew: 'New',
  filterPlanned: 'Planned',
  filterInProgress: 'In Progress',
  filterDone: 'Done',
  titlePlaceholder: 'Feature title',
  descriptionPlaceholder: 'Describe the feature...',
  submit: 'Submit',
  cancel: 'Cancel',
  empty: 'No feature requests yet',
  emptyHint: 'Be the first to suggest a feature!',
  error: 'Something went wrong',
  retry: 'Retry',
};
