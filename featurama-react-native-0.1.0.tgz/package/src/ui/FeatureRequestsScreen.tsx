import { useState, useCallback, useEffect, useMemo } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet } from 'react-native';
import { useFeaturama } from '../hooks/useFeaturama';
import { useRequests } from '../hooks/useRequests';
import { createTheme } from './theme/createTheme';
import { ThemeContext } from './theme/ThemeContext';
import { defaultStrings } from './strings/en';
import { getOrCreateVoterId } from './utils/voterId';
import { Header } from './components/Header';
import { FilterTabs } from './components/FilterTabs';
import { CreateRequestForm } from './components/CreateRequestForm';
import { RequestList } from './components/RequestList';
import type { FeatureRequestsScreenProps } from './types';
import type { FeaturamaStrings } from './strings/en';
import type { RequestFilter } from '../types';

export function FeatureRequestsScreen({
  colorScheme,
  accentColor,
  onClose,
  safeAreaTop = 0,
  strings: stringOverrides,
}: FeatureRequestsScreenProps): JSX.Element {
  const theme = useMemo(
    () => createTheme(accentColor, colorScheme),
    [accentColor, colorScheme]
  );

  const strings: FeaturamaStrings = useMemo(
    () => ({ ...defaultStrings, ...stringOverrides }),
    [stringOverrides]
  );

  const { client } = useFeaturama();

  const [activeFilter, setActiveFilter] = useState<RequestFilter>('new');
  const [isAdding, setIsAdding] = useState(false);
  const [voterId, setVoterId] = useState<string | null>(null);
  const [votingIds, setVotingIds] = useState<Set<string>>(new Set());

  const { data, isLoading, error, refetch } = useRequests({
    pageSize: 50,
    filter: activeFilter,
  });

  useEffect(() => {
    getOrCreateVoterId().then(setVoterId);
  }, []);

  const handleSubmit = useCallback(
    async (title: string, description: string) => {
      if (!voterId) return;
      await client.createRequest({
        title,
        description,
        submitterIdentifier: voterId,
      });
      setIsAdding(false);
      await refetch();
    },
    [voterId, client, refetch]
  );

  const handleToggleVote = useCallback(
    async (requestId: string) => {
      if (!voterId || votingIds.has(requestId)) return;

      setVotingIds((prev) => new Set(prev).add(requestId));
      try {
        await client.toggleVote(requestId, voterId);
        await refetch();
      } finally {
        setVotingIds((prev) => {
          const next = new Set(prev);
          next.delete(requestId);
          return next;
        });
      }
    },
    [voterId, votingIds, client, refetch]
  );

  return (
    <ThemeContext.Provider value={theme}>
      <KeyboardAvoidingView
        style={[styles.container, { backgroundColor: theme.background }]}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Header
          strings={strings}
          onClose={onClose}
          onAdd={() => setIsAdding(true)}
          insetTop={safeAreaTop}
        />
        <FilterTabs
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
          strings={strings}
        />
        {isAdding && (
          <CreateRequestForm
            strings={strings}
            onSubmit={handleSubmit}
            onCancel={() => setIsAdding(false)}
          />
        )}
        <RequestList
          data={data}
          isLoading={isLoading}
          error={error}
          votingIds={votingIds}
          strings={strings}
          onToggleVote={handleToggleVote}
          onRefetch={refetch}
        />
      </KeyboardAvoidingView>
    </ThemeContext.Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
