import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet } from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { ChevronUpIcon } from '../icons';
import type { FeatureRequest } from '../../types';

interface RequestCardProps {
  request: FeatureRequest;
  isVoting: boolean;
  onToggleVote: (id: string) => void;
}

export function RequestCard({ request, isVoting, onToggleVote }: RequestCardProps): JSX.Element {
  const theme = useTheme();

  return (
    <View style={[styles.requestItem, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <TouchableOpacity
        style={[styles.voteButton, { backgroundColor: theme.accentLight }]}
        onPress={() => onToggleVote(request.id)}
        disabled={isVoting}
      >
        {isVoting ? (
          <ActivityIndicator size="small" color={theme.accent} />
        ) : (
          <>
            <ChevronUpIcon size={20} color={theme.accent} />
            <Text style={[styles.voteCount, { color: theme.accent }]}>{request.voteCount}</Text>
          </>
        )}
      </TouchableOpacity>
      <View style={styles.requestContent}>
        <Text style={[styles.requestTitle, { color: theme.text }]}>{request.title}</Text>
        {request.description ? (
          <Text style={[styles.requestDescription, { color: theme.textSecondary }]} numberOfLines={2}>
            {request.description}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  requestItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
    gap: 12,
  },
  voteButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    minWidth: 48,
  },
  voteCount: {
    fontSize: 14,
    fontWeight: '700',
    marginTop: 2,
  },
  requestContent: {
    flex: 1,
  },
  requestTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  requestDescription: {
    fontSize: 13,
    marginTop: 4,
    lineHeight: 18,
  },
});
