import { View } from 'react-native';

interface IconProps {
  size: number;
  color: string;
}

export function CloseIcon({ size, color }: IconProps): JSX.Element {
  const thickness = Math.max(2, size * 0.12);
  const diagonal = size * 0.6;

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          position: 'absolute',
          width: diagonal,
          height: thickness,
          backgroundColor: color,
          borderRadius: thickness / 2,
          transform: [{ rotate: '45deg' }],
        }}
      />
      <View
        style={{
          position: 'absolute',
          width: diagonal,
          height: thickness,
          backgroundColor: color,
          borderRadius: thickness / 2,
          transform: [{ rotate: '-45deg' }],
        }}
      />
    </View>
  );
}

export function PlusIcon({ size, color }: IconProps): JSX.Element {
  const thickness = Math.max(2, size * 0.12);
  const barLength = size * 0.6;

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          position: 'absolute',
          width: barLength,
          height: thickness,
          backgroundColor: color,
          borderRadius: thickness / 2,
        }}
      />
      <View
        style={{
          position: 'absolute',
          width: thickness,
          height: barLength,
          backgroundColor: color,
          borderRadius: thickness / 2,
        }}
      />
    </View>
  );
}

export function ChevronUpIcon({ size, color }: IconProps): JSX.Element {
  const thickness = Math.max(2, size * 0.12);
  const armLength = size * 0.35;

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: armLength,
          height: thickness,
          backgroundColor: color,
          borderRadius: thickness / 2,
          position: 'absolute',
          left: size * 0.15,
          transform: [{ rotate: '-45deg' }],
        }}
      />
      <View
        style={{
          width: armLength,
          height: thickness,
          backgroundColor: color,
          borderRadius: thickness / 2,
          position: 'absolute',
          right: size * 0.15,
          transform: [{ rotate: '45deg' }],
        }}
      />
    </View>
  );
}

export function SendIcon({ size, color }: IconProps): JSX.Element {
  const thickness = Math.max(2, size * 0.1);

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      {/* Arrow shaft */}
      <View
        style={{
          position: 'absolute',
          width: size * 0.55,
          height: thickness,
          backgroundColor: color,
          borderRadius: thickness / 2,
          transform: [{ rotate: '-45deg' }, { translateX: -size * 0.05 }],
        }}
      />
      {/* Arrow head - top */}
      <View
        style={{
          position: 'absolute',
          width: size * 0.3,
          height: thickness,
          backgroundColor: color,
          borderRadius: thickness / 2,
          top: size * 0.2,
          right: size * 0.18,
          transform: [{ rotate: '0deg' }],
        }}
      />
      {/* Arrow head - right */}
      <View
        style={{
          position: 'absolute',
          width: thickness,
          height: size * 0.3,
          backgroundColor: color,
          borderRadius: thickness / 2,
          top: size * 0.2,
          right: size * 0.18,
          transform: [{ rotate: '0deg' }],
        }}
      />
    </View>
  );
}
