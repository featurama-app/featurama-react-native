export interface FeaturamaTheme {
  // Backgrounds
  background: string;
  card: string;
  secondary: string;

  // Text
  text: string;
  textSecondary: string;

  // Accent
  accent: string;
  accentLight: string;
  accentForeground: string;

  // Borders
  border: string;
  borderAccent: string;

  // Neutrals
  gray100: string;
}
