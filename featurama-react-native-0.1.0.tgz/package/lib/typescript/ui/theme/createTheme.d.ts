import type { FeaturamaTheme } from './types';
export declare function createTheme(accentColor: string, colorScheme: 'light' | 'dark'): FeaturamaTheme;
//# sourceMappingURL=createTheme.d.ts.map