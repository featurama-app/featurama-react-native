export interface FeaturamaTheme {
    background: string;
    card: string;
    secondary: string;
    text: string;
    textSecondary: string;
    accent: string;
    accentLight: string;
    accentForeground: string;
    border: string;
    borderAccent: string;
    gray100: string;
}
//# sourceMappingURL=types.d.ts.map