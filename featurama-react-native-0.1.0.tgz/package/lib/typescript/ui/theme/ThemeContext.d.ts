import type { FeaturamaTheme } from './types';
export declare const ThemeContext: import("react").Context<FeaturamaTheme | null>;
export declare function useTheme(): FeaturamaTheme;
//# sourceMappingURL=ThemeContext.d.ts.map