import type { FeatureRequestsScreenProps } from './types';
export declare function FeatureRequestsScreen({ colorScheme, accentColor, onClose, safeAreaTop, strings: stringOverrides, }: FeatureRequestsScreenProps): JSX.Element;
//# sourceMappingURL=FeatureRequestsScreen.d.ts.map