export declare function getOrCreateVoterId(): Promise<string>;
//# sourceMappingURL=voterId.d.ts.map