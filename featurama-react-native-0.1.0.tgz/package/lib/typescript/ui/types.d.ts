import type { FeaturamaStrings } from './strings/en';
export interface FeatureRequestsScreenProps {
    colorScheme: 'light' | 'dark';
    accentColor: string;
    onClose?: () => void;
    safeAreaTop?: number;
    strings?: Partial<FeaturamaStrings>;
}
//# sourceMappingURL=types.d.ts.map