interface IconProps {
    size: number;
    color: string;
}
export declare function CloseIcon({ size, color }: IconProps): JSX.Element;
export declare function PlusIcon({ size, color }: IconProps): JSX.Element;
export declare function ChevronUpIcon({ size, color }: IconProps): JSX.Element;
export declare function SendIcon({ size, color }: IconProps): JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map