export interface FeaturamaStrings {
    title: string;
    filterNew: string;
    filterPlanned: string;
    filterInProgress: string;
    filterDone: string;
    titlePlaceholder: string;
    descriptionPlaceholder: string;
    submit: string;
    cancel: string;
    empty: string;
    emptyHint: string;
    error: string;
    retry: string;
}
export declare const defaultStrings: FeaturamaStrings;
//# sourceMappingURL=en.d.ts.map