import type { RequestFilter } from '../../types';
import type { FeaturamaStrings } from '../strings/en';
interface FilterTabsProps {
    activeFilter: RequestFilter;
    onFilterChange: (filter: RequestFilter) => void;
    strings: FeaturamaStrings;
}
export declare function FilterTabs({ activeFilter, onFilterChange, strings }: FilterTabsProps): JSX.Element;
export {};
//# sourceMappingURL=FilterTabs.d.ts.map