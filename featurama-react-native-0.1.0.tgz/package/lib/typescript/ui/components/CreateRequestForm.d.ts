import type { FeaturamaStrings } from '../strings/en';
interface CreateRequestFormProps {
    strings: FeaturamaStrings;
    onSubmit: (title: string, description: string) => Promise<void>;
    onCancel: () => void;
}
export declare function CreateRequestForm({ strings, onSubmit, onCancel, }: CreateRequestFormProps): JSX.Element;
export {};
//# sourceMappingURL=CreateRequestForm.d.ts.map