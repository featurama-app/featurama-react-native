import type { FeatureRequest, PaginatedResponse } from '../../types';
import type { FeaturamaStrings } from '../strings/en';
interface RequestListProps {
    data: PaginatedResponse<FeatureRequest> | null;
    isLoading: boolean;
    error: Error | null;
    votingIds: Set<string>;
    strings: FeaturamaStrings;
    onToggleVote: (id: string) => void;
    onRefetch: () => Promise<void>;
}
export declare function RequestList({ data, isLoading, error, votingIds, strings, onToggleVote, onRefetch, }: RequestListProps): JSX.Element;
export {};
//# sourceMappingURL=RequestList.d.ts.map