import type { FeaturamaStrings } from '../strings/en';
interface HeaderProps {
    strings: FeaturamaStrings;
    onClose?: () => void;
    onAdd: () => void;
    insetTop: number;
}
export declare function Header({ strings, onClose, onAdd, insetTop }: HeaderProps): JSX.Element;
export {};
//# sourceMappingURL=Header.d.ts.map