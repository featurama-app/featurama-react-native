import type { FeatureRequest } from '../../types';
interface RequestCardProps {
    request: FeatureRequest;
    isVoting: boolean;
    onToggleVote: (id: string) => void;
}
export declare function RequestCard({ request, isVoting, onToggleVote }: RequestCardProps): JSX.Element;
export {};
//# sourceMappingURL=RequestCard.d.ts.map