import type { FeaturamaConfig, FeatureRequest, PaginatedResponse, CreateFeatureRequestInput, UpdateFeatureRequestInput, GetRequestsOptions, ToggleVoteResult } from './types';
/**
 * Featurama API client for interacting with the public SDK endpoints
 */
export declare class FeaturamaClient {
    private readonly apiKey;
    private readonly baseUrl;
    private readonly timeout;
    constructor(config: FeaturamaConfig);
    /**
     * Make an authenticated request to the API
     */
    private request;
    /**
     * Get paginated list of feature requests
     */
    getRequests(options?: GetRequestsOptions): Promise<PaginatedResponse<FeatureRequest>>;
    /**
     * Create a new feature request
     */
    createRequest(input: CreateFeatureRequestInput): Promise<FeatureRequest>;
    /**
     * Update an existing feature request (only allowed by the original submitter)
     */
    updateRequest(id: string, input: UpdateFeatureRequestInput, submitterIdentifier: string): Promise<FeatureRequest>;
    /**
     * Vote for a feature request
     */
    vote(requestId: string, voterIdentifier: string): Promise<FeatureRequest>;
    /**
     * Remove vote from a feature request
     */
    removeVote(requestId: string, voterIdentifier: string): Promise<FeatureRequest>;
    /**
     * Toggle vote on a feature request
     * If already voted, removes the vote. If not voted, adds a vote.
     * Returns the updated request and whether the user is now voting.
     */
    toggleVote(requestId: string, voterIdentifier: string): Promise<ToggleVoteResult>;
}
//# sourceMappingURL=client.d.ts.map