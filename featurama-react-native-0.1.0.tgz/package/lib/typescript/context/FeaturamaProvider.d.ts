import { type ReactNode } from 'react';
import type { FeaturamaConfig, FeaturamaContextValue } from '../types';
export declare const FeaturamaContext: import("react").Context<FeaturamaContextValue | null>;
export interface FeaturamaProviderProps {
    /**
     * Configuration for the Featurama client
     */
    config: FeaturamaConfig;
    /**
     * Child components that will have access to the Featurama context
     */
    children: ReactNode;
}
/**
 * Provider component that initializes the Featurama client and makes it available
 * to all child components via React context.
 *
 * @example
 * ```tsx
 * <FeaturamaProvider config={{ apiKey: 'fm_live_...' }}>
 *   <App />
 * </FeaturamaProvider>
 * ```
 */
export declare function FeaturamaProvider({ config, children, }: FeaturamaProviderProps): JSX.Element;
//# sourceMappingURL=FeaturamaProvider.d.ts.map