/**
 * Feature request status enum matching backend values
 */
export declare enum FeatureRequestStatus {
    Requested = 0,
    Roadmap = 1,
    InProgress = 2,
    Done = 3,
    Declined = 4
}
/**
 * Feature request source enum matching backend values
 */
export declare enum FeatureRequestSource {
    SDK = 0,
    Dashboard = 1
}
/**
 * Feature request entity returned from the API
 */
export interface FeatureRequest {
    id: string;
    projectId: string;
    title: string;
    description: string;
    status: FeatureRequestStatus;
    source: FeatureRequestSource;
    voteCount: number;
    submitterIdentifier: string;
    createdAt: string;
}
/**
 * Paginated response wrapper
 */
export interface PaginatedResponse<T> {
    items: T[];
    totalCount: number;
    page: number;
    pageSize: number;
}
/**
 * Configuration for initializing the Featurama client
 */
export interface FeaturamaConfig {
    /** API key starting with 'fm_live_' */
    apiKey: string;
    /** Base URL of the Featurama API (default: https://api.featurama.io) */
    baseUrl?: string;
    /** Request timeout in milliseconds (default: 10000) */
    timeout?: number;
}
/**
 * Input for creating a new feature request
 */
export interface CreateFeatureRequestInput {
    title: string;
    description: string;
    submitterIdentifier: string;
}
/**
 * Input for updating an existing feature request
 */
export interface UpdateFeatureRequestInput {
    title: string;
    description: string;
}
/**
 * Filter for feature request lists matching the app's tab filters
 */
export type RequestFilter = 'new' | 'planned' | 'in_progress' | 'done';
/**
 * Options for fetching feature requests
 */
export interface GetRequestsOptions {
    page?: number;
    pageSize?: number;
    filter?: RequestFilter;
}
/**
 * Return type for the useRequests hook
 */
export interface UseRequestsResult {
    data: PaginatedResponse<FeatureRequest> | null;
    isLoading: boolean;
    error: Error | null;
    refetch: () => Promise<void>;
    hasNextPage: boolean;
    fetchNextPage: () => Promise<void>;
}
/**
 * Return type for vote toggle operations
 */
export interface ToggleVoteResult {
    request: FeatureRequest;
    isVoting: boolean;
}
/**
 * Context value provided by FeaturamaProvider
 */
export interface FeaturamaContextValue {
    client: import('../client').FeaturamaClient;
    isInitialized: boolean;
}
//# sourceMappingURL=index.d.ts.map