import type { FeaturamaContextValue } from '../types';
/**
 * Hook to access the Featurama client from context.
 * Must be used within a FeaturamaProvider.
 *
 * @returns The Featurama context containing the client and initialization status
 * @throws Error if used outside of FeaturamaProvider
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { client, isInitialized } = useFeaturama();
 *
 *   const handleCreateRequest = async () => {
 *     await client.createRequest({
 *       title: 'New Feature',
 *       description: 'A great new feature',
 *       submitterIdentifier: 'user-123',
 *     });
 *   };
 *
 *   return <Button onPress={handleCreateRequest}>Submit</Button>;
 * }
 * ```
 */
export declare function useFeaturama(): FeaturamaContextValue;
//# sourceMappingURL=useFeaturama.d.ts.map