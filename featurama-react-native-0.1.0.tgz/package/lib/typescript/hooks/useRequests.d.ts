import type { GetRequestsOptions, UseRequestsResult } from '../types';
/**
 * Hook for fetching and managing feature requests with pagination support.
 * Automatically fetches data on mount and provides methods for pagination and refetching.
 *
 * @param options - Optional configuration for pagination
 * @returns Object containing data, loading state, error, and control functions
 *
 * @example
 * ```tsx
 * function FeatureList() {
 *   const { data, isLoading, error, refetch, hasNextPage, fetchNextPage } = useRequests({
 *     pageSize: 10,
 *   });
 *
 *   if (isLoading) return <Text>Loading...</Text>;
 *   if (error) return <Text>Error: {error.message}</Text>;
 *
 *   return (
 *     <FlatList
 *       data={data?.items}
 *       renderItem={({ item }) => <FeatureItem request={item} />}
 *       onEndReached={() => hasNextPage && fetchNextPage()}
 *     />
 *   );
 * }
 * ```
 */
export declare function useRequests(options?: GetRequestsOptions): UseRequestsResult;
//# sourceMappingURL=useRequests.d.ts.map