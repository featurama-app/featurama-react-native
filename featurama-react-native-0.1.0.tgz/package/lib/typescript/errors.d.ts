/**
 * Error codes for Featurama SDK errors
 */
export declare enum FeaturamaErrorCode {
    INVALID_API_KEY = "INVALID_API_KEY",
    UNAUTHORIZED = "UNAUTHORIZED",
    FORBIDDEN = "FORBIDDEN",
    NOT_FOUND = "NOT_FOUND",
    CONFLICT = "CONFLICT",
    VALIDATION_ERROR = "VALIDATION_ERROR",
    NETWORK_ERROR = "NETWORK_ERROR",
    TIMEOUT = "TIMEOUT",
    UNKNOWN = "UNKNOWN"
}
/**
 * Custom error class for Featurama SDK errors
 */
export declare class FeaturamaError extends Error {
    readonly code: FeaturamaErrorCode;
    readonly statusCode?: number;
    readonly details?: unknown;
    constructor(message: string, code: FeaturamaErrorCode, statusCode?: number, details?: unknown);
    /**
     * Create error from HTTP response
     */
    static fromResponse(response: Response): Promise<FeaturamaError>;
    /**
     * Create network error
     */
    static networkError(originalError?: Error): FeaturamaError;
    /**
     * Create timeout error
     */
    static timeout(timeoutMs: number): FeaturamaError;
    /**
     * Create invalid API key error
     */
    static invalidApiKey(): FeaturamaError;
}
//# sourceMappingURL=errors.d.ts.map